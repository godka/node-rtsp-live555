/*!
 * rtsp-live555
 * MIT Licensed
 */

'use strict';

module.exports = require('./lib/rtsp-live555');
